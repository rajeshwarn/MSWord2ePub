using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Tidy.Net")]
[assembly: AssemblyDescription("Native .NET HTML Tidy")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("(c) 1998-2000 (W3C) MIT, INRIA, Keio University")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
